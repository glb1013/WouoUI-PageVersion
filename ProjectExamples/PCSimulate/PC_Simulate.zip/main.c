#include "WouoUI/WouoUI.h"
#include "WouoUI/WouoUI_user.h"
#include "stdint.h"
#include "math.h"
#include <conio.h>
#include <graphics.h>
#include <time.h>

#define FORE_COLOR LIGHTBLUE     // 前景颜色
#define BACK_COLOR WHITE         // 背景颜色

// #define FORE_COLOR BLACK     // 前景颜色
// #define BACK_COLOR RGB(197,235,165) // 背景颜色 //护眼苹果绿

#define pixelSeize 3

uint16_t fps = 0;
uint16_t sinA = 3, sinB = 0;


void simulateSendBuff(uint8_t buff[WOUOUI_BUFF_HEIGHT_BYTE_NUM][WOUOUI_BUFF_WIDTH]) {
    BeginBatchDraw();
    cleardevice();
    for (uint8_t i = 0; i < WOUOUI_BUFF_HEIGHT_BYTE_NUM; i++)
        for (uint16_t j = 0; j < WOUOUI_BUFF_WIDTH; j++)
            for (uint8_t n = 0; n < 8; n++) {
                if (buff[i][j] & 0x01 << n) {
                    uint16_t x = j * pixelSeize, y = (i * 8 + n) * pixelSeize;
                    fillrectangle(x, y, x + pixelSeize - 1, y + pixelSeize - 1);
                }
            }
    EndBatchDraw();
    fps++;
}

void TimerEvent1() {
    WouoUI_Proc(20);
    // 给波形页面的波形赋值
    static float phase1 = 0;
    phase1 += 0.1;
    if (phase1 > 6.28)
        phase1 = 0;
    WouoUI_WavePageUpdateVal(&wave_page, 0, sinA * sin(phase1));
}

void TimerEvent2() {
    if(GetAsyncKeyState(VK_ESCAPE))WOUOUI_MSG_QUE_SEND(msg_return);
    if(GetAsyncKeyState(VK_UP)) WOUOUI_MSG_QUE_SEND(msg_up);
    if(GetAsyncKeyState(VK_LEFT)) WOUOUI_MSG_QUE_SEND(msg_left);
    if(GetAsyncKeyState(VK_SPACE)) WOUOUI_MSG_QUE_SEND(msg_click);
    if(GetAsyncKeyState(VK_DOWN)) WOUOUI_MSG_QUE_SEND(msg_down);
    if(GetAsyncKeyState(VK_RIGHT)) WOUOUI_MSG_QUE_SEND(msg_right);
    
       if (GetAsyncKeyState(VK_F4))
        sinA = 0;
    if (GetAsyncKeyState(VK_F5))
        sinA = 10;
    if (GetAsyncKeyState(VK_F6))
        sinA = 50;
    if (GetAsyncKeyState(VK_F7))
        sinA = 100;
    if (GetAsyncKeyState(VK_F8))
        sinB = 0;
    if (GetAsyncKeyState(VK_F9))
        sinB = 10;
    if (GetAsyncKeyState(VK_F10))
        sinB = 50;
    

    // 给波形页面的波形赋值
    static float phase2 = 3.14/2;
    phase2 += 0.1;
    if (phase2 > 6.28)
        phase2 = 0;
    WouoUI_WavePageUpdateVal(&wave_page, 1, sinB * sin(phase2));
} 

void TimerEvent3() {
    printf("fps:%d\n", fps);
    fps = 0;
}


int main() {
    // easyz window
    initgraph(WOUOUI_BUFF_WIDTH * pixelSeize, WOUOUI_BUFF_HEIGHT * pixelSeize, NOCLOSE);
    HWND hwnd = GetHWnd();
    SetWindowPos(hwnd, NULL, 650, 120, WOUOUI_BUFF_WIDTH * pixelSeize, WOUOUI_BUFF_HEIGHT * pixelSeize, SWP_NOSIZE | SWP_NOZORDER);
    SetWindowText(hwnd, (char *)"WouoUI Simulate");
    
    // set color
    setcolor(FORE_COLOR);
    setfillcolor(FORE_COLOR);
    setbkcolor(BACK_COLOR);
    cleardevice();
    WouoUI_AttachSendBuffFun(simulateSendBuff); //绑定刷新Buff的函数
    // WouoUI,先运行Init函数,防止事件中先调用了UI_Proc函数,导致指针为空
    TestUI_Init();
    // timer
    SetTimer(hwnd, 1, 20, (TIMERPROC)TimerEvent1);
    SetTimer(hwnd, 2, 200, (TIMERPROC)TimerEvent2);
    SetTimer(hwnd, 3, 1000, (TIMERPROC)TimerEvent3);



    while (1) {
    }

    closegraph();
    return 0;
}
